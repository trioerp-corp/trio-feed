import json

from django.core.exceptions import ValidationError
from django.http import Http404, HttpResponse, JsonResponse
from django.shortcuts import render
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt

from core.models import CompanySettings

from . import services as P
from .models import Device


def _device(request):
    if not CompanySettings.get().pos_enabled:
        return None, JsonResponse({"error": "نقاط البيع غير مفعلة"}, status=403)
    tok = request.headers.get("X-Device-Token", "")
    dev = Device.objects.filter(token=tok, active=True, branch__active=True).select_related("branch", "branch__cashbox", "branch__warehouse").first()
    if not dev:
        return None, JsonResponse({"error": "مفتاح الجهاز غير صحيح"}, status=401)
    return dev, None


def app(request):
    if not CompanySettings.get().pos_enabled:
        raise Http404("نقاط البيع غير مفعلة")
    return render(request, "pos/app.html")


def sw(request):
    js = """const C='gg-pos-v1';self.addEventListener('install',e=>e.waitUntil(caches.open(C).then(c=>c.addAll(['/pos/']))));
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(e.request.method!=='GET'||u.pathname.startsWith('/pos/api/'))return;
e.respondWith(fetch(e.request).then(r=>{const cp=r.clone();caches.open(C).then(c=>c.put(e.request,cp));return r}).catch(()=>caches.match(e.request)))});"""
    return HttpResponse(js, content_type="application/javascript")


def api_catalog(request):
    dev, err = _device(request)
    if err:
        return err
    return JsonResponse(P.catalog(dev))


@csrf_exempt
def api_sync(request):
    dev, err = _device(request)
    if err:
        return err
    if request.method != "POST":
        return JsonResponse({"error": "POST only"}, status=405)
    body = json.loads(request.body or "{}")
    accepted, errors = [], {}
    for sh in body.get("shifts", []):
        if sh.get("closed_at"):
            continue  # closes after its orders
        P.ingest_shift(dev, sh)
    for o in body.get("orders", []):
        try:
            P.ingest_order(dev, o)
            accepted.append(o["uid"])
        except ValidationError as e:
            errors[o.get("uid", "?")] = "؛ ".join(e.messages)
    moved = []
    for m in body.get("cash_moves", []):
        try:
            P.ingest_cash_move(dev, m)
            moved.append(m["uid"])
        except ValidationError as e:
            errors[m.get("uid", "?")] = "؛ ".join(e.messages)
    reqs = []
    for r in body.get("requests", []):
        try:
            P.ingest_request(dev, r)
            reqs.append(r["uid"])
        except (ValidationError, KeyError) as e:
            errors[r.get("uid", "?")] = str(e)
    closed = []
    for sh in body.get("shifts", []):
        if sh.get("closed_at"):
            P.ingest_shift(dev, sh)
            closed.append(sh["uid"])
    dev.last_sync = timezone.now()
    dev.save(update_fields=["last_sync"])
    return JsonResponse({"accepted": accepted, "cash_moves": moved, "requests": reqs, "errors": errors, "closed_shifts": closed})


@csrf_exempt
def api_cashier(request):
    dev, err = _device(request)
    if err:
        return err
    body = json.loads(request.body or "{}")
    u = P.verify_cashier(body.get("username", ""), body.get("password", ""))
    if not u:
        return JsonResponse({"ok": False, "error": "اسم الكاشير أو كلمة السر غلط"}, status=403)
    return JsonResponse({"ok": True, "name": u.first_name or u.username})
