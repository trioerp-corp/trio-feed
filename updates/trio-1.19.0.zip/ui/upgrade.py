"""The owner's «ترقية وطلبات» page: what he has, what he can add (with prices), and a request that reaches Trio by e-mail.
Plus the update notices: «تحديث جاهز» (install now) and «تم التحديث لأحدث إصدار»."""
import json

from core.middleware import safe_next
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.shortcuts import redirect, render
from django.utils import timezone

from core import license as LIC
from core import modules as M
from core import updates as U
from core.models import CompanySettings
from core.version import VERSION


def _owner(request):
    from pos.branches import is_owner_level

    if not (request.user.is_superuser or is_owner_level(request.user)):
        raise PermissionDenied("الصفحة دي لصاحب النشاط")


@login_required
def page(request):
    _owner(request)
    s = CompanySettings.get()
    mods = M.enabled(s)
    demo = not s.license_code  # the free trial: nothing paid yet → full prices, every plan can be picked
    plans = [(k, v[0], M.PLAN_PRICES[k], M.PLAN_PRICES[k] - (0 if demo else M.PLAN_PRICES.get(s.plan, 0))) for k, v in M.PLANS.items()]
    addons = [(k, M.MODULES[k][0], M.MODULES[k][1], M.ADDON_PRICES[k]) for k in M.ADDON_PRICES if k not in mods and M.fits(k, s.business)]
    have = [(k, M.MODULES[k][0]) for k in M.MODULES if k in mods]
    if request.method == "POST":
        want = request.POST.getlist("want")
        plan = request.POST.get("plan", "")
        services = request.POST.getlist("service")
        note = request.POST.get("note", "").strip()[:1000]
        phone = request.POST.get("phone", "").strip()[:40] or s.phone
        kind = request.POST.get("kind", "upgrade")
        if request.POST.get("pay") == "card":
            return _pay(request, s, demo, plan, want, services, phone)
        lines = [f"طلب من برنامج Trio — {s.name}", f"النشاط: {M.BUSINESS.get(s.business, ('',))[0]}", f"الباقة الحالية: {M.PLANS.get(s.plan, ('',))[0]}",
                 f"نسخة البرنامج: {VERSION}", f"كود الجهاز: {LIC.machine_code()}", f"التليفون: {phone}", f"صاحب الطلب: {request.user.get_full_name() or request.user.username}", ""]
        total = 0
        if kind == "update":
            from core.feed import newer_available

            nv = newer_available()
            lines.append("المطلوب: أحدث إصدار من البرنامج" + (f" ({nv})" if nv else ""))
        if demo and plan in M.PLANS:
            lines.append(f"المطلوب: الاشتراك في باقة {M.PLANS[plan][0]} ({M.PLAN_PRICES[plan]:,} ج)")
            total += M.PLAN_PRICES[plan]
            plan = ""
        if plan in M.PLANS and plan != s.plan:
            diff = M.PLAN_PRICES[plan] - M.PLAN_PRICES.get(s.plan, 0)
            lines.append(f"ترقية الباقة إلى: {M.PLANS[plan][0]} (الفرق {diff:,} ج)")
            total += max(diff, 0)
        for k in want:
            if k in M.ADDON_PRICES:
                lines.append(f"إضافة: {M.MODULES[k][0]} ({M.ADDON_PRICES[k]:,} ج)")
                total += M.ADDON_PRICES[k]
        for k in services:
            sv = next((x for x in M.SERVICES if x[0] == k), None)
            if sv:
                lines.append(f"خدمة: {sv[1]} ({sv[2]:,} ج)")
                total += sv[2]
        if note:
            lines += ["", "ملاحظات: " + note]
        if total:
            lines += ["", f"الإجمالي التقريبي: {total:,} جنيه"]
        if len(lines) <= 8 and not note:
            messages.error(request, "اختار حاجة أو اكتب طلبك")
            return redirect("upgrade")
        text = "\n".join(lines)
        subject = f"TRIO-REQUEST — {s.name} — " + ("أحدث إصدار" if kind == "update" else "اشتراك" if demo else "ترقية / ميزة")
        from core.devaccess import sender

        if not sender() and not s.smtp_user:  # copies without a mailbox (every online copy): WhatsApp straight away
            from urllib.parse import quote

            request.session["wa_request"] = f"https://wa.me/201008030459?text={quote(text)}"
            messages.success(request, "طلبك جاهز ✔ — اضغط «ابعت الطلب واتساب»" + (" وهيوصلك كود التفعيل بعد الدفع" if demo else ""))
            return redirect("upgrade")
        try:
            from core.devaccess import DEV_EMAIL
            from core.reports_send import send_mail_to

            send_mail_to(s, DEV_EMAIL, subject, text)
            messages.success(request, "اتبعت طلبك لـ Trio ✔ — هنكلمك قريب. لما يتوافق عليه بيتفعّل عندك لوحده.")
            log = U.folder() / "requests.json"
            old = json.loads(log.read_text(encoding="utf-8")) if log.exists() else []
            old.append(dict(at=timezone.now().isoformat(), text=text))
            log.write_text(json.dumps(old[-30:], ensure_ascii=False), encoding="utf-8")
        except Exception as e:  # noqa: BLE001 — no internet / no mailbox: WhatsApp instead
            from urllib.parse import quote

            request.session["wa_request"] = f"https://wa.me/201008030459?text={quote(text)}"
            messages.error(request, f"الطلب متبعتش على الإيميل ({type(e).__name__}) — ابعته واتساب من الزرار اللي تحت")
        return redirect("upgrade")
    lic = LIC.status(s)
    owned = {"lifetime": lic.get("lifetime"), "renew": lic.get("lifetime"), "lifetime_updates": lic.get("lifetime_updates")}
    services = [x for x in M.SERVICES if not owned.get(x[0]) and not x[0].startswith("lifetime")]
    forever = [x for x in M.SERVICES if x[0].startswith("lifetime") and not owned.get(x[0])]
    auto = bool(lic.get("lifetime_updates") or (not lic.get("lifetime") and lic["state"] in ("active", "warning")))
    log = U.folder() / "requests.json"
    return render(request, "ui/upgrade.html", dict(demo=demo, s=s, plans=plans, addons=addons, have=have, services=services, forever=forever, auto=auto, version=VERSION, lic=lic,
                                                  machine=LIC.machine_code(), st=U.state(), pay_ok=_pay_ok(s), wa=request.session.pop("wa_request", ""),
                                                  sent=list(reversed(json.loads(log.read_text(encoding="utf-8")) if log.exists() else []))[:5]))


def _pay_ok(s):
    from core import pay

    return pay.enabled()


def _pay(request, s, demo, plan, want, services, phone):
    """«💳 ادفع بالفيزا»: the Worker prices it, Paymob takes the money, the licence comes back by itself."""
    from core import pay

    sel = dict(plan=plan if plan in M.PLANS and (demo or plan != s.plan) else "", extras=[k for k in want if k in M.ADDON_PRICES],
               life=[k for k in services if k in ("lifetime", "lifetime_updates")], renew="renew" in services, phone=phone)
    if not request.POST.get("agree"):
        messages.error(request, "علّم إنك قريت ووافقت على الشروط والأحكام وسياسة الاسترجاع قبل الدفع")
        return redirect("upgrade")
    from core.legal import TERMS_VERSION

    sel["agree"] = TERMS_VERSION
    if demo and not sel["plan"]:
        messages.error(request, "اختار الباقة الأول")
        return redirect("upgrade")
    if not (sel["plan"] or sel["extras"] or sel["life"] or sel["renew"]):
        messages.error(request, "اختار باقة أو إضافة تدفعها بالفيزا (الخدمات والزيارات بتتطلب واتساب)")
        return redirect("upgrade")
    try:
        res = pay.checkout(sel, s, request.build_absolute_uri("/ui/shop/pay/"))
    except pay.PayError as e:
        messages.error(request, str(e))
        return redirect("upgrade")
    if [k for k in services if k not in ("lifetime", "lifetime_updates", "renew")]:
        messages.warning(request, "الخدمات (جهاز إضافي، زيارة، تعديل خاص…) مش في الدفع ده — اطلبها واتساب")
    return redirect(res["url"])


@login_required
def paid(request):
    """Back from Paymob: wait for the confirmation, then install the licence (the page refreshes itself)."""
    _owner(request)
    from core import feed, pay

    s = CompanySettings.get()
    oid = request.GET.get("id") or feed.state().get("pay_order") or ""
    status, err = "", ""
    if oid:
        try:
            res = pay.order(oid, s)
            status = res.get("status", "")
            if status == "paid" and res.get("code"):
                feed._save(pay_order="", pay_done=oid)
                if "".join(res["code"].split()) != s.license_code:
                    for lvl, msg in pay.activate(res["code"], s):
                        getattr(messages, lvl)(request, msg)
                messages.success(request, f"تم الدفع ✔ — طلب رقم {oid}. شكرًا لاختيارك Trio")
                return redirect("/")
        except (pay.PayError, ValueError) as e:
            err = str(e)
    return render(request, "ui/pay_wait.html", dict(oid=oid, status=status, err=err))


@login_required
def update_now(request):
    _owner(request)
    if request.method == "POST" and U.state()["ready"]:
        (U.folder() / "now.flag").write_text(timezone.now().isoformat())
        (U.folder() / "failed.txt").unlink(missing_ok=True)
        messages.success(request, "التحديث هيتركّب خلال دقيقة — البرنامج هيقف ثواني ويرجع. لو حد بيبيع على الكاشير بيكمل عادي ويزامن بعدها.")
    return redirect(safe_next(request))


@login_required
def seen(request):
    _owner(request)
    if request.method == "POST":
        f = U.folder()
        what = request.POST.get("what")
        if what == "upgrade":
            (f / "seen-upgrade.txt").write_text("1")
        else:
            st = U.state()
            if st["applied"]:
                (f / "seen.txt").write_text(st["applied"]["v"])
    return redirect(safe_next(request))


def notice(request):
    """For the header: only the owner sees update / upgrade notices."""
    try:
        from pos.branches import is_owner_level

        if not (request.user.is_authenticated and (request.user.is_superuser or is_owner_level(request.user))):
            return {}
        st = U.state()
        f = U.folder()
        up = json.loads((f / "upgraded.json").read_text(encoding="utf-8")) if (f / "upgraded.json").exists() and not (f / "seen-upgrade.txt").exists() else None
        return dict(upd_ready=st["ready"], upd_applied=st["applied"] if st["applied"] and st["seen"] != st["applied"]["v"] else None,
                    upd_failed=st["failed"], upgraded=up, acc_version=VERSION)
    except Exception:  # noqa: BLE001
        return {}
