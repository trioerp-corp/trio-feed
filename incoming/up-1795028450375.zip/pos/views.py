import json
import logging

from django.core.exceptions import ValidationError
from django.db import transaction
from django.http import Http404, HttpResponse, JsonResponse
from django.shortcuts import render
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt

from core.models import CompanySettings

from . import services as P
from .models import Device


def _device(request):
    if not CompanySettings.get().pos_enabled:
        return None, JsonResponse({"error": "نقاط البيع غير مفعلة"}, status=403)
    tok = request.headers.get("X-Device-Token", "")
    dev = Device.objects.filter(token=tok, active=True, branch__active=True).select_related("branch", "branch__cashbox", "branch__warehouse").first()
    if not dev:
        return None, JsonResponse({"error": "مفتاح الجهاز غير صحيح"}, status=401)
    return dev, None


def app(request):
    if not CompanySettings.get().pos_enabled:
        raise Http404("نقاط البيع غير مفعلة")
    return render(request, "pos/app.html")


def sw(request):
    js = """const C='gg-pos-v1';self.addEventListener('install',e=>e.waitUntil(caches.open(C).then(c=>c.addAll(['/pos/']))));
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(e.request.method!=='GET'||u.pathname.startsWith('/pos/api/'))return;
e.respondWith(fetch(e.request).then(r=>{const cp=r.clone();caches.open(C).then(c=>c.put(e.request,cp));return r}).catch(()=>caches.match(e.request)))});"""
    return HttpResponse(js, content_type="application/javascript")


def api_catalog(request):
    dev, err = _device(request)
    if err:
        return err
    return JsonResponse(P.catalog(dev))


@csrf_exempt
def api_sync(request):
    dev, err = _device(request)
    if err:
        return err
    if request.method != "POST":
        return JsonResponse({"error": "POST only"}, status=405)
    try:
        body = json.loads(request.body or "{}")
    except ValueError:
        return JsonResponse({"error": "bad json"}, status=400)
    accepted, errors = [], {}

    def each(rows, fn, done):
        """One bad paper never blocks the rest of the queue: it is reported (and logged) and the others go in."""
        for row in rows or []:
            uid = str((row or {}).get("uid", "?")) if isinstance(row, dict) else "?"
            try:
                with transaction.atomic():
                    fn(row)
                done.append(uid)
            except ValidationError as e:
                errors[uid] = "؛ ".join(e.messages)
            except Exception as e:  # noqa: BLE001 — a malformed row (missing field, bad number) or a fault in posting
                logging.getLogger("trio").exception("POS sync: %s refused", uid)
                errors[uid] = f"تعذّر التسجيل ({type(e).__name__}) — بلّغ الدعم"

    opened, moved, reqs, closed = [], [], [], []
    shifts = [sh for sh in body.get("shifts") or [] if isinstance(sh, dict)]
    each([sh for sh in shifts if not sh.get("closed_at")], lambda sh: P.ingest_shift(dev, sh), opened)
    sold = set()

    def take(o):
        order, _ = P.ingest_order(dev, o, renumber=True)
        sold.update(order.lines.values_list("item_id", flat=True))

    each(body.get("orders"), take, accepted)
    each(body.get("cash_moves"), lambda m: P.ingest_cash_move(dev, m), moved)
    each(body.get("requests"), lambda r: P.ingest_request(dev, r), reqs)
    each([sh for sh in shifts if sh.get("closed_at")], lambda sh: P.ingest_shift(dev, sh), closed)  # closes after its orders
    if dev.stuck != errors:
        dev.stuck = errors
        dev.save(update_fields=["stuck"])
    dev.last_sync = timezone.now()
    dev.save(update_fields=["last_sync"])
    low = []
    if sold:  # «حد الطلب» reached by these sales (recipe ingredients included) — the till shows it in a pop-up
        from inventory.reorder import low as low_items

        low = low_items(sold)
    return JsonResponse({"accepted": accepted, "cash_moves": moved, "requests": reqs, "errors": errors, "closed_shifts": closed, "low": low})


@csrf_exempt
def api_cashier(request):
    dev, err = _device(request)
    if err:
        return err
    from core import throttle as TH

    try:
        body = json.loads(request.body or "{}")
    except ValueError:
        body = {}
    name = str(body.get("username", ""))
    if TH.blocked(name, f"dev{dev.pk}"):
        return JsonResponse({"ok": False, "error": TH.MSG}, status=403)
    u = P.verify_cashier(name, body.get("password", ""))
    if not u:
        TH.fail(name, f"dev{dev.pk}")
        return JsonResponse({"ok": False, "error": "اسم الكاشير أو كلمة السر غير صحيحة"}, status=403)
    TH.clear(name)
    return JsonResponse({"ok": True, "name": u.first_name or u.username})


@csrf_exempt
def api_kitchen(request):
    """The kitchen ticket of a new order on the kitchen printer (1.22) — printed by the computer the program runs on."""
    dev, err = _device(request)
    if err:
        return err
    if request.method != "POST":
        return JsonResponse({"error": "POST فقط"}, status=405)
    s = CompanySettings.get()
    if s.kitchen_ticket != "printer":
        return JsonResponse({"error": "طابعة المطبخ غير مفعلة"}, status=409)
    try:
        body = json.loads(request.body or "{}")
        o = body.get("o") if isinstance(body.get("o"), dict) else {}
        if not str(o.get("uid", "")).startswith(f"{dev.branch.code}-{dev.code}-") or not isinstance(o.get("lines"), list):
            return JsonResponse({"error": "طلب غير صحيح"}, status=400)
        from . import kitchen

        kitchen.print_order(o, str(body.get("cashier") or "")[:60])
    except (ValueError, TypeError):
        return JsonResponse({"error": "طلب غير صحيح"}, status=400)
    except RuntimeError as e:
        return JsonResponse({"error": str(e)}, status=503)
    except OSError as e:  # noqa: BLE001 — the printer driver
        logging.getLogger(__name__).warning("kitchen printer: %s", e)
        return JsonResponse({"error": "تعذرت الطباعة على طابعة المطبخ"}, status=503)
    return JsonResponse({"ok": True})
